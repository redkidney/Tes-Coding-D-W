var mysql = require('mysql');
const bodyParser = require('body-parser');
const express = require('express');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "komisi"
});

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");

    con.query("SELECT * FROM job", function (err, result, fields) {
      if (err) throw err;
      console.log(result);
    });
  });


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/getEmployeeNames', (req, res) => {
  con.query("SELECT id_employee, name FROM employee", function (err, result, fields) {
    if (err) {
      console.error('Error executing MySQL query: ' + err.stack);
      res.status(500).json({ message: 'Error' });
    } else {
      res.json(result);
    }
  });
});

app.post('/hitungKomisi', (req, res) => {
  const EmployeeId = req.body.id_employee;
  var  period_job  = req.body.Period;
  var  amount  = req.body.Amount;
  var  gross_profit = req.body.Gross_profit;

    console.log("Received data:", { EmployeeId, period_job, amount, gross_profit });

    const total_commission = 0.1 * gross_profit;
    const query = 'INSERT INTO job (id_employee, period_job, amount, gross_profit, total_commission) VALUES (?, ?, ?, ?, ?)';
    
    con.query(query, [EmployeeId, period_job, amount, gross_profit, total_commission], (err, result) => {
    if (err) {
      console.error('Error executing MySQL query: ' + err.stack);
      res.status(500).json({ message: 'Error' });
    } else {
      res.status(200).json({ message: 'Komisi berhasil dihitung', total_commission: total_commission });
    }
  });
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});



